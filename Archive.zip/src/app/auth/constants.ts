export const jwtConstants = {
  secret: 'kisra_secret',
};
